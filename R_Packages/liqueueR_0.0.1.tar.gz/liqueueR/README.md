# liqueueR

A R package which implements Queue and PriorityQueue classes.

## Installation

To install simply
```
devtools::install_github("DataWookie/liqueueR")
```

## To Do

- Implement tests.

## Queue

## PriorityQueue