library(testthat)
library(liqueueR)

test_check("liqueueR")
